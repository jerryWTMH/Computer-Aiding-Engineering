clear
close all
reply='a';
while(reply=='a')
    
    camera=webcam;
    reply=input('��enter�i����','s');
    if isempty(reply)   
    photo=snapshot(camera);
    end
end
imwrite(photo,'photo.jpg','jpg');
image1= 'photo.jpg';
image2=photo;
pattern='.jpg';
pattern2='.pgm';
newString = strrep(image1, pattern, pattern2);
imwrite(image2,newString, 'pgm');
I = imread(newString);
FDetect = vision.CascadeObjectDetector();
bbox = step(FDetect,I);
foundface = insertObjectAnnotation(I,'rectangle',bbox,'Face');
I2 = imcrop(I,bbox);
I3= imresize(I2,[112 92]);
imwrite(I3,newString,'pgm');
faceDatabase = imageSet('FaceDatabaseATT','recursive');
[training,test] = partition(faceDatabase,[0.8 0.2]);
person = 10;
[hogFeature, visualization]= ...
    extractHOGFeatures(read(training(person),1));
trainingFeatures = zeros(size(training,2)*training(1).Count,4680);
featureCount = 1;
for i=1:size(training,2)
    for j = 1:training(i).Count
        trainingFeatures(featureCount,:) = extractHOGFeatures(read(training(i),j));
        trainingLabel{featureCount} = training(i).Description;    
        featureCount = featureCount + 1;
    end
    personIndex{i} = training(i).Description;
end
faceClassifier = fitcecoc(trainingFeatures,trainingLabel);
queryImage = I3;
queryFeatures = extractHOGFeatures(queryImage);
personLabel = predict(faceClassifier,queryFeatures);
booleanIndex = strcmp(personLabel, personIndex);
integerIndex = find(booleanIndex);
number=personLabel;
subplot(1,2,1);imshow(queryImage);title('�q�q�ڬO��?');
subplot(1,2,2);imshow(read(training(integerIndex),1));title(number);
clear
clear
